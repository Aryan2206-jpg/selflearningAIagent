@echo off
setlocal
cd /d "%~dp0"
title NeuroLearn - Self Learning AI Agent
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py") else (set "PY=python")
%PY% -m pip show streamlit >nul 2>&1
if errorlevel 1 (
 echo Installing Streamlit...
 %PY% -m pip install -r requirements.txt
 if errorlevel 1 (echo Installation failed. & pause & exit /b 1)
)
%PY% -m streamlit run app.py
pause

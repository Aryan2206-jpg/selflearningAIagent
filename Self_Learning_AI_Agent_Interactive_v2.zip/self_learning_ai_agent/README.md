# NeuroLearn — Self-Learning AI Agent

A modern, interactive local Streamlit application with a chat UI, teach-the-agent form, feedback-based retrieval, SQLite persistent memory, analytics dashboard, search, and JSON/CSV export.

## Windows one-click start
1. Extract the ZIP.
2. Open the `self_learning_ai_agent` folder.
3. Double-click `run_app.bat`. The first launch installs Streamlit if needed.
4. Open http://localhost:8501 if your browser does not open automatically.

## VS Code
Open the folder containing `app.py` and run `py -m streamlit run app.py` in the VS Code terminal. Do not use the Python Run File button.

## How it learns
This is a local **feedback-based retrieval demo**, not a neural network that retrains itself. Teach it answers in the Teach Agent page; positively rated examples are prioritized for similar questions. No API key is needed. The app stores data in `agent_memory.db` next to the app file.

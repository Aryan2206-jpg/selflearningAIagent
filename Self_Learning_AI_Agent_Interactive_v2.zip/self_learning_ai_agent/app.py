import streamlit as st
import sqlite3, re, json, csv, io
from pathlib import Path
from datetime import datetime
from collections import Counter

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'agent_memory.db'
ICON = ROOT / 'app_icon.png'
st.set_page_config(page_title='NeuroLearn | Self-Learning AI Agent', page_icon=str(ICON) if ICON.exists() else '🧠', layout='wide', initial_sidebar_state='expanded')

st.markdown('''<style>
.stApp{background:radial-gradient(ellipse at 70% 0%,#1b1740 0%,#0b1020 50%,#090d19 100%);color:#e9ecff}
[data-testid="stSidebar"]{background:#10142b;border-right:1px solid #33365e}
.block-container{padding-top:2rem;max-width:1200px}
h1,h2,h3{letter-spacing:-.03em}
[data-testid="stMetric"]{background:#161b37;border:1px solid #343960;border-radius:18px;padding:16px}
.stButton>button{border-radius:12px;border:1px solid #56518b}
.stButton>button[kind="primary"]{background:linear-gradient(100deg,#7c3aed,#3b82f6);border:0}
[data-testid="stChatMessage"]{background:#171d39;border:1px solid #31395f;border-radius:16px}
.hero{padding:24px 28px;border:1px solid #50469a;border-radius:22px;background:linear-gradient(120deg,#211747,#10234a);margin-bottom:22px}
.hero h1{margin:0;font-size:2.1rem}.hero p{color:#c4c7e5;margin:8px 0 0}
.pill{display:inline-block;padding:6px 12px;border-radius:99px;background:#302560;color:#d9cbff;margin:10px 8px 0 0;font-size:.85rem}
</style>''', unsafe_allow_html=True)

def db():
    con=sqlite3.connect(DB)
    con.execute('CREATE TABLE IF NOT EXISTS memory(id INTEGER PRIMARY KEY AUTOINCREMENT,user_input TEXT NOT NULL,response TEXT NOT NULL,feedback INTEGER DEFAULT 0,created_at TEXT NOT NULL)')
    return con

def rows():
    with db() as con:
        return con.execute('SELECT id,user_input,response,feedback,created_at FROM memory ORDER BY id DESC').fetchall()

def save(q,a):
    with db() as con:
        cur=con.execute('INSERT INTO memory(user_input,response,created_at) VALUES(?,?,?)',(q,a,datetime.now().isoformat(timespec='seconds')))
        return cur.lastrowid

def vote(rid, value):
    with db() as con: con.execute('UPDATE memory SET feedback=? WHERE id=?',(value,rid))

def words(s):return set(re.findall(r'[a-z0-9]+',s.lower()))

def reply(q):
    query=words(q)
    matches=[]
    for row in rows():
        if row[3]<0:continue
        candidate=words(row[1]); similarity=len(query&candidate)/len(query|candidate) if query|candidate else 0
        if similarity>=.42 and row[1].lower()!=q.lower():matches.append((similarity+(.15 if row[3]>0 else 0),row))
        if row[1].lower()==q.lower() and row[3]>0:matches.append((2,row))
    if matches:
        _,item=max(matches,key=lambda x:x[0])
        return '🧠 **Learned from a previous interaction**\n\n'+item[2]+'\n\n_This answer was retrieved from local memory. Rate it to help improve future retrieval._'
    low=q.lower()
    if any(x in low for x in ('hello','hey','hi there')):return 'Hello! 👋 I am NeuroLearn. Ask me a question, teach me an answer, or rate my responses to build my local memory.'
    if 'how do you learn' in low or 'how does this app' in low:return 'I store interactions in SQLite, compare new questions to old ones using word overlap, and prioritize positively rated answers. I do **not** retrain a neural network or access the internet.'
    if 'python' in low:return '🐍 **Python plan**\n\n1. Define the input and expected output.\n2. Break the task into functions.\n3. Test edge cases.\n4. Refactor and document your solution.\n\nTell me the specific Python problem and teach me your preferred answer in the **Teach Agent** tab.'
    if any(x in low for x in ('study','learn','exam')):return '📚 **Study plan**\n\n- Set a clear goal and deadline.\n- Study in focused 25-minute blocks.\n- Practice active recall with questions.\n- Review weak topics every few days.\n- Track progress weekly.'
    return '✨ I have not learned a reliable answer to that yet. Use **Teach Agent** to give me a trusted response, or ask a more specific question. My local knowledge grows through saved examples and feedback.'

if 'messages' not in st.session_state:st.session_state.messages=[]
with st.sidebar:
    if ICON.exists():st.image(str(ICON),width=84)
    st.title('NeuroLearn')
    st.caption('Your personal learning companion • v2.0')
    page=st.radio('Explore', ['💬 Chat','🎓 Teach Agent','📊 Dashboard','🧠 Memory','⚙️ Settings'],label_visibility='collapsed')
    st.divider()
    all_rows=rows(); liked=sum(r[3]==1 for r in all_rows)
    st.metric('Saved interactions',len(all_rows))
    st.metric('Helpful answers',liked)
    st.caption('🔒 Your memory stays on this computer.')

if page=='💬 Chat':
    st.markdown('<div class="hero"><h1>✨ Your Self-Learning AI Agent</h1><p>Ask questions, give feedback, and build a smarter personal knowledge base.</p><span class="pill">🧠 Persistent memory</span><span class="pill">👍 Feedback learning</span><span class="pill">🔒 Offline & private</span></div>',unsafe_allow_html=True)
    if not st.session_state.messages:
        st.info('👋 Welcome! Choose a starter below or write your own question.')
        options=['How does this app learn?','Give me a Python study plan','Help me prepare for an exam']
        cols=st.columns(3)
        for c,p in zip(cols,options):
            if c.button(p,use_container_width=True):st.session_state.pending=p
    for m in st.session_state.messages:
        with st.chat_message(m['role'],avatar='🧠' if m['role']=='assistant' else '👤'):
            st.markdown(m['content'])
            if m['role']=='assistant' and 'id' in m:
                c1,c2,c3=st.columns([1,1,5])
                if c1.button('👍',key=f"up{m['id']}",help='Helpful'):vote(m['id'],1);st.toast('Saved as helpful!')
                if c2.button('👎',key=f"down{m['id']}",help='Not helpful'):vote(m['id'],-1);st.toast('Feedback saved')
    prompt=st.chat_input('Ask NeuroLearn anything...')
    if not prompt:prompt=st.session_state.pop('pending',None)
    if prompt and prompt.strip():
        answer=reply(prompt.strip());rid=save(prompt.strip(),answer)
        st.session_state.messages.extend([{'role':'user','content':prompt},{'role':'assistant','content':answer,'id':rid}]);st.rerun()
    if st.button('🧹 Clear visible chat'):st.session_state.messages=[];st.rerun()

elif page=='🎓 Teach Agent':
    st.title('🎓 Teach the Agent')
    st.write('Give NeuroLearn a question and the answer you want it to remember. Your example will be stored locally and can be retrieved for similar questions.')
    with st.form('teach'):
        question=st.text_input('Question or trigger',placeholder='What is machine learning?')
        answer=st.text_area('Correct answer',height=160,placeholder='Machine learning is...')
        submitted=st.form_submit_button('💾 Save as learned knowledge',type='primary')
    if submitted:
        if question.strip() and answer.strip():rid=save(question.strip(),answer.strip());vote(rid,1);st.success('Knowledge saved! Try asking the question in Chat.')
        else:st.warning('Please enter both a question and an answer.')

elif page=='📊 Dashboard':
    st.title('📊 Learning Dashboard')
    data=rows();total=len(data);positive=sum(r[3]>0 for r in data);negative=sum(r[3]<0 for r in data)
    c1,c2,c3,c4=st.columns(4)
    c1.metric('Conversations',total);c2.metric('Helpful',positive);c3.metric('Needs improvement',negative);c4.metric('Positive feedback',f'{positive/(positive+negative)*100:.0f}%' if positive+negative else '—')
    st.subheader('Popular learned topics')
    counts=Counter(w for r in data if r[3]>0 for w in words(r[1]) if len(w)>3)
    if counts:st.bar_chart(dict(counts.most_common(12)),horizontal=True)
    else:st.info('Teach the agent or rate an answer 👍 to see learning insights.')
    st.subheader('Recent activity')
    if data:st.dataframe([{'Date':r[4],'Question':r[1],'Feedback':'👍' if r[3]>0 else '👎' if r[3]<0 else 'Not rated'} for r in data[:20]],hide_index=True,use_container_width=True)

elif page=='🧠 Memory':
    st.title('🧠 Memory Library')
    data=rows();search=st.text_input('🔎 Search stored knowledge',placeholder='Search by question or answer...')
    kind=st.selectbox('Filter feedback',['All','Helpful','Not helpful','Unrated'])
    filtered=[r for r in data if (not search or search.lower() in (r[1]+' '+r[2]).lower()) and (kind=='All' or (kind=='Helpful' and r[3]>0) or (kind=='Not helpful' and r[3]<0) or (kind=='Unrated' and r[3]==0))]
    st.caption(f'{len(filtered)} memories found')
    for r in filtered:
        with st.expander(('👍' if r[3]>0 else '👎' if r[3]<0 else '💬')+' '+r[1][:90]):
            st.markdown(r[2]);st.caption(r[4]);a,b,c=st.columns([1,1,5])
            if a.button('👍',key=f'mup{r[0]}'):vote(r[0],1);st.rerun()
            if b.button('👎',key=f'mdown{r[0]}'):vote(r[0],-1);st.rerun()
            if c.button('🗑️ Delete',key=f'del{r[0]}'):
                with db() as con:con.execute('DELETE FROM memory WHERE id=?',(r[0],))
                st.rerun()
    if not filtered:st.info('No matching memories found.')

else:
    st.title('⚙️ Settings & Backup')
    st.write('Export your data, or reset the locally stored memory.')
    data=rows()
    payload=[{'id':r[0],'question':r[1],'answer':r[2],'feedback':r[3],'created_at':r[4]} for r in data]
    st.download_button('⬇️ Export memory (JSON)',json.dumps(payload,indent=2,ensure_ascii=False),file_name='neurolearn_memory.json',mime='application/json')
    buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=['id','question','answer','feedback','created_at']);writer.writeheader();writer.writerows(payload)
    st.download_button('⬇️ Export memory (CSV)',buffer.getvalue(),file_name='neurolearn_memory.csv',mime='text/csv')
    st.divider();st.warning('Deleting memory is permanent. Export a backup first.')
    confirm=st.checkbox('I understand that all stored knowledge will be deleted')
    if st.button('🗑️ Reset all memory',disabled=not confirm):
        with db() as con:con.execute('DELETE FROM memory')
        st.session_state.messages=[];st.success('All memory deleted.');st.rerun()
    st.caption('Learning here means feedback-weighted retrieval and explicitly taught examples, not model retraining.')
